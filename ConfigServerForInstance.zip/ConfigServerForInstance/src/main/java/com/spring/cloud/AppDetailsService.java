package com.spring.cloud;

import org.cloudfoundry.client.v3.applications.Application;
import reactor.core.publisher.Mono;

public interface AppDetailsService {
	Mono<AppDetail> getApplicationDetail(String applicationId);
}
